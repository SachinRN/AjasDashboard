import React from 'react'

function Employeeprofile() {
  return (
    <div>
      <section>
      <div class="container-fluid">

<h1 class="h3 mb-2 text-gray-800">Employee Profile</h1>
<p class="mb-4"> <a target="_blank"
        href="#"></a>.</p>

<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">Employee Tables</h6>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <thead>
                    <tr>
                        <th>Employee No.</th>
                        <th>Employee Name</th>
                        <th>EmailId</th>
                        <th>Phone No.</th>
                        <th>Age</th>
                        <th>Address</th>
                        <th>Start date</th>
                    </tr>
                </thead>
                
                <tbody>
                    <tr>
                        <td>20001</td>
                        <td>Sachin</td>
                        <td>abc@gmail.com</td>
                        <td>7552532652</td>
                        <td>26</td>
                        <td>Pune</td>
                        <td>2023/01/25</td>
                    </tr>
                    <tr>
                        <td>20002</td>
                        <td>Sagar</td>
                        <td>sa@gmail.com</td>
                        <td>7521526526</td>
                        <td>26</td>
                        <td>Pune</td>
                        <td>2023/02/10</td>
                    </tr>
                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                </div>
                </section>
            </div>
    
    
  )
}

export default Employeeprofile