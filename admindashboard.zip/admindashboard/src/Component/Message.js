import React from 'react'

function Message() {
  return (
    <div>Message</div>
  )
}

export default Message