import React,{useState} from 'react'
import './App.css';
import Dropdown from 'react-bootstrap/Dropdown';
import DropdownButton from 'react-bootstrap/DropdownButton';
import Dashboard from './Component/Dashboard';
import Websiteanalytics from './Component/Websiteanalytics';
import Employeeprofile from './Component/Employeeprofile';
import Admindetails from './Component/Admindetails';
import Message from './Component/Message';
import Login from './Component/Login';
import Register from './Component/Register';
import Forgotpassword from './Component/Forgotpassword';
import {
  BrowserRouter as Router,
  Switch,
  Route,
  Link
} from "react-router-dom";


function App() {
    const [style,setStyle]=useState("navbar-nav bg-gradient-primary sidebar sidebar-dark accordion");

    const changeStyle = ( ) => {
        if (style == "navbar-nav bg-gradient-primary sidebar sidebar-dark accordion")
        {
            setStyle("navbar-nav bg-gradient-primary sidebar sidebar-dark accordion toggled");
        }
        else{
            setStyle("navbar-nav bg-gradient-primary sidebar sidebar-dark accordion");
        }
        
    };
    const changeStyle1 = ( ) => {
        if (style == "navbar-nav bg-gradient-primary sidebar sidebar-dark accordion")
        {
            setStyle("navbar-nav bg-gradient-primary sidebar sidebar-dark accordion toggled1");
        }
        else{
            setStyle("navbar-nav bg-gradient-primary sidebar sidebar-dark accordion");
        }
        
    };
  return (
    <Router>

    <div>
        <body id="page-top">

{/* <!-- Page Wrapper --> */}
<div id="wrapper">

    {/*<!-- Sidebar -->*/}
    <ul className={style} id="accordionSidebar">

        {/*<!-- Sidebar - Brand -->*/}
        <a className="sidebar-brand d-flex align-items-center justify-content-center" href="Dashboard">
            <div className="sidebar-brand-icon rotate-n-15">
                <img src='ajaslogo.jpg' className="im1"/>
                <i className="AJAS"></i>
            </div>
            <div className="sidebar-brand-text mx-3">AJAS SERVICES <sup></sup></div>
            
        </a>

        {/*<!-- Divider -->*/}

        <hr className="sidebar-divider my-0"/>
        
{/*         <!-- Nav Item - Dashboard -->
*/}
        <li className="nav-item active">
            <a className="nav-link" href="Dashboard">
                <i className="fas fa-fw fa-tachometer-alt"></i>
                <span>Dashboard</span></a>
        </li>
{/* <!-- Divider -->*/}
        <hr className="sidebar-divider"/>
{/*<!-- Heading --> */}
        
{/*<!-- Nav Item - Pages Collapse Menu --> */}
        
<li className="nav-item">
            <a className="nav-link" href ="Websiteanalytics">
                <i className="fas fa-chart-pie"></i>
                <span>Website Analytics</span></a>
        </li>
        <hr className="sidebar-divider"/>
        <li className="nav-item">
            <a className="nav-link" href ="Employeeprofile">
                <i className="fas fa-user-alt"></i>
                <span>Employee Profile</span></a>
        </li>
        <hr className="sidebar-divider"/>
        <li className="nav-item">
            <a className="nav-link" href ="Admindetails">
                <i className="fas fa-user-alt"></i>
                <span>Admin Details</span></a>
        </li>
        <hr className="sidebar-divider"/>
        <li className="nav-item">
            <a className="nav-link" href ="Message">
                <i className="far fa-comment-alt"></i>
                <span>Message</span></a>
        </li>
{/* <!-- Nav Item - Utilities Collapse Menu -->*/}
<hr className="sidebar-divider"/>
        
{/*<!-- Divider --> */}
        
        
{/*<!-- Heading --> */}
        
        
{/*<!-- Nav Item - Pages Collapse Menu --> */}
<li class="nav-item">
                <div className="nav-link collapsed" data-toggle="collapse" data-target="#collapsePages"
                    aria-expanded="true" aria-controls="collapsePages">
                    <i className="fas fa-fw fa-cog"></i>
                    <span>Setting</span>
                </div>
                <div id="collapsePages" class="collapse" aria-labelledby="headingPages" data-parent="#accordionSidebar">
                    <div className="bg-white py-2 collapse-inner rounded">
                        <h6 className="collapse-header">Login Screens:</h6>
                        <a className="collapse-item" href="Login">Login</a>
                        <a className="collapse-item" href="Register">Register</a>
                        <a className="collapse-item" href="Forgotpassword">Forgot Password</a>
                        <div className="collapse-divider"></div>
                        
                    </div>
                </div>
            </li>
            <hr className="sidebar-divider"/>
        <li className="nav-item">
            <a className="nav-link" href ="Login">
                <i className="fas fa-user-alt"></i>
                <span>Logout</span></a>
        </li>
        
{/*<!-- Nav Item - Charts --> */}
        
        
{/* <!-- Divider -->*/}
        
{/*        <!-- Sidebar Toggler (Sidebar) -->
 */}
        <div className="text-center d-none d-md-inline">
            <button className="rounded-circle border-0" id="sidebarToggle" onClick={changeStyle}></button>
        </div>
{/*         <!-- Sidebar Message -->
*/}
        

    </ul>
    {/*    <!-- End of Sidebar -->
 */}
{/*    <!-- Content Wrapper -->
 */}
    <div id="content-wrapper" className="d-flex flex-column">
{/*        <!-- Main Content -->
 */}
        <div id="content">
{/*            <!-- Topbar -->
 */}
            <nav className="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">
{/*                <!-- Sidebar Toggle (Topbar) -->
 */}
                <button id="sidebarToggleTop" className="btn btn-link d-md-none rounded-circle mr-3" onClick={changeStyle1}>
                    <i className="fa fa-bars"></i>
                </button>
{/*                 <!-- Topbar Search -->
*/}
                <form
                    className="d-none d-sm-inline-block form-inline mr-auto ml-md-3 my-2 my-md-0 mw-100 navbar-search">
                    <div className="input-group">
                        <input type="text" className="form-control bg-light border-0 small" placeholder="Search for..."
                            aria-label="Search" aria-describedby="basic-addon2"/>
                        <div className="input-group-append">
                            <button className="btn btn-primary" type="button">
                                <i className="fas fa-search fa-sm"></i>
                            </button>
                        </div>
                    </div>
                </form>
{/*                 <!-- Topbar Navbar -->
*/}
                <ul className="navbar-nav ml-auto">
{/*                     <!-- Nav Item - Search Dropdown (Visible Only XS) -->
*/}
                    <li className="nav-item dropdown no-arrow d-sm-none">
                        <a className="nav-link dropdown-toggle" href="#" id="searchDropdown" role="button"
                            data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <i className="fas fa-search fa-fw"></i>
                        </a>
 {/*                         <!-- Dropdown - Messages -->
*/}                       
                        <div className="dropdown-menu dropdown-menu-right p-3 shadow animated--grow-in"
                            aria-labelledby="searchDropdown">
                            <form className="form-inline mr-auto w-100 navbar-search">
                                <div className="input-group">
                                    <input type="text" className="form-control bg-light border-0 small"
                                        placeholder="Search for..." aria-label="Search"
                                        aria-describedby="basic-addon2"/>
                                    <div className="input-group-append">
                                        <button className="btn btn-primary" type="button">
                                            <i className="fas fa-search fa-sm"></i>
                                        </button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </li>
{/*                    <!-- Nav Item - Alerts -->
 */}
                    <li className="nav-item dropdown no-arrow mx-1">
                        <a className="nav-link dropdown-toggle" href="#" id="alertsDropdown" role="button"
                            data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <i className="fas fa-bell fa-fw"></i>
 {/*                             <!-- Counter - Alerts -->
*/}                           
                            <span className="badge badge-danger badge-counter">1+</span>
                        </a>
 {/*                         <!-- Dropdown - Alerts -->
*/}                       
                        <div className="dropdown-list dropdown-menu dropdown-menu-right shadow animated--grow-in"
                            aria-labelledby="alertsDropdown">
                            <h6 className="dropdown-header">
                                Alerts Center
                            </h6>
                            <a className="dropdown-item d-flex align-items-center" href="#">
                                <div className="mr-3">
                                    <div className="icon-circle bg-primary">
                                        <i className="fas fa-file-alt text-white"></i>
                                    </div>
                                </div>
                                <div>
                                    <div className="small text-gray-500">December 12, 2019</div>
                                    <span className="font-weight-bold">A new monthly report is ready to download!</span>
                                </div>
                            </a>
                            
                            
                            <a className="dropdown-item text-center small text-gray-500" href="#">Show All Alerts</a>
                        </div>
                    </li>
{/*                     <!-- Nav Item - Messages -->
*/}
                    <li className="nav-item dropdown no-arrow mx-1">
                        <a className="nav-link" href="Message" id="messagesDropdown" role="button">
                            <i className="fas fa-envelope fa-fw"></i>
 {/*                             <!-- Counter - Messages -->
*/}                           
                            <span className="badge badge-danger badge-counter">1</span>
                        </a>
 {/*                         <!-- Dropdown - Messages -->
*/}                       
                        
                    </li>

                    <div className="topbar-divider d-none d-sm-block"></div>
{/*                    <!-- Nav Item - User Information -->
 */}
                    <li className="nav-item dropdown no-arrow">
                        
                        
                        <DropdownButton className="d1" id="dropdown-basic-button" title="Sachin">
      <Dropdown.Item href="Admindetails">Admin Profile</Dropdown.Item>
      <Dropdown.Item href="Settings">Setting</Dropdown.Item>
      <Dropdown.Item href="Login">Logout</Dropdown.Item>
    </DropdownButton>
                        
                    </li>

                </ul>

            </nav>
 {/*            <!-- End of Topbar -->
 */}     

      





{/*             <!-- Begin Page Content -->
*/}
            <div className="container-fluid">
{/*                 <!-- Page Heading -->
*/}
                <div className="d-sm-flex align-items-center justify-content-between mb-4">
                    <a href="Dashboard.js" className="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i
                            className="fas fa-download fa-sm text-white-50"></i> Generate Report</a>
                </div>
{/*                <!-- Content Row -->
 */}
                
{/*                 <!-- Content Row -->
*/}

                

                

            </div>
            

        </div>
        
        <Switch>
          <Route exact path="/Dashboard">
            <Dashboard />
          </Route>
          <Route path="/Websiteanalytics">
            <Websiteanalytics />
          </Route>
          <Route path="/Employeeprofile">
            <Employeeprofile />
          </Route>
          <Route path="/Admindetails">
            <Admindetails />
          </Route>
          <Route path="/Message">
            <Message />
          </Route>
          <Route path="/Login">
            <Login />
          </Route>
          <Route path="/Register">
            <Register />
          </Route>
          <Route path="/Forgotpassword">
            <Forgotpassword />
          </Route>
        </Switch>
        
      
{/*         <!-- Footer -->
*/}
        <footer className="sticky-footer bg-white">
            <div className="container my-auto">
                <div className="copyright text-center my-auto">
                    <span>*Copyright* &copy; ###</span>
                </div>
            </div>
        </footer>
 {/*        <!-- End of Footer -->
 */}       

    </div>
 {/*    <!-- End of Content Wrapper -->
 */}   

</div>

{/* <!-- End of Page Wrapper -->
*/}
{/*<!-- Scroll to Top Button-->
 */}
<a className="scroll-to-top rounded" href="#page-top">
    <i className="fas fa-angle-up"></i>
</a>
{/*<!-- Logout Modal-->
 */}
<div className="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
    aria-hidden="true">
    <div className="modal-dialog" role="document">
        <div className="modal-content">
            <div className="modal-header">
                <h5 className="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
                <button className="close" type="button" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <div className="modal-body">Select "Logout" below if you are ready to end your current session.</div>
            <div className="modal-footer">
                <button className="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                <a className="btn btn-primary" href="login.html">Logout</a>
            </div>
        </div>
    </div>
</div>



</body>
    </div>
    </Router>

  )
}

export default App